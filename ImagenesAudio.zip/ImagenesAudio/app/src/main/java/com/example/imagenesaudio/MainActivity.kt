package com.example.imagenesaudio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.imagenesaudio.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.imageButton.setOnClickListener(){

            binding.balon.setImageResource(R.drawable.ic_sport1)
        }
        binding.imageButton2.setOnClickListener(){
            binding.balon.setImageResource(R.drawable.ic_sport2)
        }


    }
}