package com.example.conexionyloginantonio

data class User(var born:String, var first:String, var last:String, val rol:String)

