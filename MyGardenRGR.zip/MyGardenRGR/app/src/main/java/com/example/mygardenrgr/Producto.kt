package com.example.mygardenrgr

import java.io.Serializable

data class Producto(var email:String, var nombre:String, var procedencia:String, var cantidad:String, var imagen: String) : Serializable