package com.example.mygardenrgr

enum class Rol {
    ADMIN,
    BASIC
}