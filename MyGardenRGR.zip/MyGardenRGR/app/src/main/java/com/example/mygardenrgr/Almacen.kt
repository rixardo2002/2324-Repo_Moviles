package com.example.mygardenrgr

object Almacen {
    lateinit var productos : ArrayList<Producto>
}