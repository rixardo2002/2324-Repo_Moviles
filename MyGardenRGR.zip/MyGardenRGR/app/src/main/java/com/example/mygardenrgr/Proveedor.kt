package com.example.loginconexion

enum class Proveedor {
    EMAIL,
    GOOGLE
}