package Modelo

import java.io.Serializable

data class Futbolista(var nombre:String, var apellido:String, var equipo:String) : Serializable
