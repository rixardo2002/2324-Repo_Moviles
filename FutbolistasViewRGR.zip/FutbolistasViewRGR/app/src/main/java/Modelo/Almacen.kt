package Modelo

object Almacen {
    lateinit var futbolistas : ArrayList<Futbolista>
}